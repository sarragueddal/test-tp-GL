/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

/**
 *
 * @author boudaoud
 */
public class ImpossibleMoveException extends Exception { 
} 

